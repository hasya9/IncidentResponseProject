from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Explicitly written 50 Malicious IPs
default_data = {
    "malicious_ips": [
        "192.168.1.1", "192.168.1.2", "192.168.1.3", "192.168.1.4", "192.168.1.5",
        "192.168.1.6", "192.168.1.7", "192.168.1.8", "192.168.1.9", "192.168.1.10",
        "192.168.1.11", "192.168.1.12", "192.168.1.13", "192.168.1.14", "192.168.1.15",
        "203.0.113.1", "203.0.113.2", "203.0.113.3", "203.0.113.4", "203.0.113.5",
        "203.0.113.6", "203.0.113.7", "203.0.113.8", "203.0.113.9", "203.0.113.10",
        "203.0.113.11", "203.0.113.12", "203.0.113.13", "203.0.113.14", "203.0.113.15",
        "10.0.0.1", "10.0.0.2", "10.0.0.3", "10.0.0.4", "10.0.0.5",
        "10.0.0.6", "10.0.0.7", "10.0.0.8", "10.0.0.9", "10.0.0.10",
        "172.16.0.1", "172.16.0.2", "172.16.0.3", "172.16.0.4", "172.16.0.5"
    ],
    
    # Explicitly written 50 Malicious Domains
    "malicious_domains": [
        "malicious1.com", "malicious2.com", "malicious3.com", "malicious4.com", "malicious5.com",
        "malicious6.com", "malicious7.com", "malicious8.com", "malicious9.com", "malicious10.com",
        "phishing1.net", "phishing2.net", "phishing3.net", "phishing4.net", "phishing5.net",
        "phishing6.net", "phishing7.net", "phishing8.net", "phishing9.net", "phishing10.net",
        "hacker1.org", "hacker2.org", "hacker3.org", "hacker4.org", "hacker5.org",
        "hacker6.org", "hacker7.org", "hacker8.org", "hacker9.org", "hacker10.org",
        "danger1.xyz", "danger2.xyz", "danger3.xyz", "danger4.xyz", "danger5.xyz",
        "danger6.xyz", "danger7.xyz", "danger8.xyz", "danger9.xyz", "danger10.xyz",
        "scam1.site", "scam2.site", "scam3.site", "scam4.site", "scam5.site"
    ],

    # 10 OWASP Vulnerabilities
    "vulnerabilities": {
        "Injection": {
            "severity": "High",
            "techniques": ["SQL Injection", "NoSQL Injection", "Command Injection"],
            "recovery_methods": ["Sanitize Inputs", "Use Prepared Statements", "Whitelist Inputs"]
        },
        "Broken Authentication": {
            "severity": "High",
            "techniques": ["Credential Stuffing", "Brute Force Attacks"],
            "recovery_methods": ["Implement Multi-Factor Authentication", "Secure Password Storage"]
        },
        "Sensitive Data Exposure": {
            "severity": "High",
            "techniques": ["Insecure Data Storage", "Weak Encryption"],
            "recovery_methods": ["Encrypt Sensitive Data", "Use Strong Encryption Algorithms"]
        },
        "Security Misconfiguration": {
            "severity": "Medium",
            "techniques": ["Default Settings", "Unnecessary Features Enabled"],
            "recovery_methods": ["Review and Harden Configurations", "Regularly Update Software"]
        },
        "Cross-Site Scripting (XSS)": {
            "severity": "Medium",
            "techniques": ["Stored XSS", "Reflected XSS", "DOM-based XSS"],
            "recovery_methods": ["Escape Outputs", "Implement Content Security Policy"]
        },
        "Insecure Deserialization": {
            "severity": "High",
            "techniques": ["Object Injection", "Remote Code Execution"],
            "recovery_methods": ["Use Safe Serialization Formats", "Validate All Serialized Data"]
        },
        "Using Components with Known Vulnerabilities": {
            "severity": "Medium",
            "techniques": ["Outdated Libraries", "Vulnerable Dependencies"],
            "recovery_methods": ["Regularly Update Dependencies", "Use Dependency Scanning Tools"]
        },
        "Insufficient Logging & Monitoring": {
            "severity": "Medium",
            "techniques": ["Lack of Logging", "Inadequate Monitoring"],
            "recovery_methods": ["Implement Comprehensive Logging", "Use Monitoring Tools"]
        },
        "Broken Access Control": {
            "severity": "High",
            "techniques": ["Unauthorized API Access", "Privilege Escalation"],
            "recovery_methods": ["Use Role-Based Access Control (RBAC)", "Restrict API Permissions"]
        },
        "XML External Entities (XXE)": {
            "severity": "Medium",
            "techniques": ["External Entity Injection"],
            "recovery_methods": ["Disable XML External Entity Processing", "Use Less Complex Data Formats"]
        }
    },

    # 10 Attack Types
    "attack_types": [
        "DDoS Attack",
        "Man-in-the-Middle (MitM) Attack",
        "Phishing Attack",
        "SQL Injection",
        "Cross-Site Scripting (XSS)",
        "Cross-Site Request Forgery (CSRF)",
        "Ransomware Attack",
        "Brute Force Attack",
        "Malware Infection",
        "Zero-Day Exploit"
    ]
}

@app.route('/')
def index():
    return render_template('index.html', vulnerabilities=default_data["vulnerabilities"], attacks=default_data["attack_types"])

@app.route('/owasp_risk_calculator')
def owasp_risk_calculator():
    return render_template('owasp_risk_calculator.html')

@app.route('/check', methods=['POST'])
def check():
    ip = request.form.get('ip')
    domain = request.form.get('domain')
    vulnerability = request.form.get('vulnerability')
    attack = request.form.get('attack')

    # Check if IP or domain is malicious
    malicious_ip = ip in default_data['malicious_ips']
    malicious_domain = domain in default_data['malicious_domains']

    # Get vulnerability details
    vulnerability_info = default_data['vulnerabilities'].get(vulnerability, {
        "severity": "Unknown",
        "techniques": ["No specific techniques available"],
        "recovery_methods": ["No recovery methods available"]
    })

    return jsonify({
        "malicious_ip": malicious_ip,
        "malicious_domain": malicious_domain,
        "severity": vulnerability_info["severity"],
        "techniques": vulnerability_info["techniques"],
        "recovery_methods": vulnerability_info["recovery_methods"],
        "attack": attack
    })

if __name__ == '__main__':
    app.run(debug=True)
